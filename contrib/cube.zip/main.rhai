// Cube Live Wallpaper - Rhai Animation Script
// Animates the isometric cube, inner/outer rays, and hollow shell.

fn init() {
    print("Cube Live Wallpaper initialized!");
}

fn update(time, delta) {
    // Theme color syncing
    for_each("Base", |transform, scale, index| transform.set_theme_color("background"));
    for_each("HexBorder", |transform, scale, index| transform.set_theme_color("color1"));
    for_each("HexBack", |transform, scale, index| transform.set_theme_color("background"));

    for_each("OuterRay1", |transform, scale, index| transform.set_theme_color("color4"));
    for_each("OuterRay2", |transform, scale, index| transform.set_theme_color("color3"));
    for_each("OuterRay3", |transform, scale, index| transform.set_theme_color("color2"));
    for_each("OuterRay4", |transform, scale, index| transform.set_theme_color("color5"));
    for_each("OuterRay5", |transform, scale, index| transform.set_theme_color("color6"));
    for_each("OuterRay6", |transform, scale, index| transform.set_theme_color("color7"));

    for_each("InnerRay1", |transform, scale, index| transform.set_theme_color("color5"));
    for_each("InnerRay2", |transform, scale, index| transform.set_theme_color("color6"));
    for_each("InnerRay3", |transform, scale, index| transform.set_theme_color("color7"));
    for_each("InnerRay4", |transform, scale, index| transform.set_theme_color("color4"));
    for_each("InnerRay5", |transform, scale, index| transform.set_theme_color("color3"));
    for_each("InnerRay6", |transform, scale, index| transform.set_theme_color("color2"));

    // 1. Whole CubeSystem gently floats and breathes
    for_each("CubeSystem", |transform, scale, index| {
        transform.y = transform.base_y + (time * 0.8).sin() * 4.0;
        transform.rot = (time * 0.3).sin() * 0.04;
        scale.set(1.0 + (time * 0.6).sin() * 0.03);
    });

    // 2. OuterRays slowly rotate clockwise and pulse outward in a wave
    for_each("OuterRays", |transform, scale, index| {
        transform.rot = time * 0.15;
        scale.set(1.0 + (time * 1.2).sin() * 0.04);
    });

    for_each("OuterRay", |transform, scale, index| {
        if transform.id != "OuterRays" {
            let i = transform.index.to_float();
            let phase = i * 1.04719755; // 60 degrees
            let wave = (time * 2.0 + phase).sin();
            transform.alpha = 0.65 + wave * 0.35;
            scale.set(1.0 + wave * 0.06);
        }
    });

    // 3. InnerRays counter-rotate and shimmer with phase offset
    for_each("InnerRays", |transform, scale, index| {
        transform.rot = -time * 0.25;
        scale.set(1.0 + (time * 1.5).cos() * 0.05);
    });

    for_each("InnerRay", |transform, scale, index| {
        if transform.id != "InnerRays" {
            let i = transform.index.to_float();
            let phase = i * 1.04719755;
            let wave = (time * 2.5 - phase).sin();
            transform.alpha = 0.7 + wave * 0.3;
            scale.set(1.0 + wave * 0.08);
        }
    });

    // 4. CoreCube levitates and pulses inside the hollow chamber
    for_each("CoreCube", |transform, scale, index| {
        transform.y = transform.base_y + (time * 1.6).sin() * 2.5;
        transform.rot = (time * 0.5).cos() * 0.06;
        scale.set(1.0 + (time * 1.6).cos() * 0.05);
    });

    // 5. OuterShell subtly counter-shifts for 3D parallax depth
    for_each("OuterShell", |transform, scale, index| {
        transform.y = transform.base_y - (time * 0.8).sin() * 1.5;
    });
}
